var structsfl_1_1_frame =
[
    [ "getFace", "structsfl_1_1_frame.html#ad8a48313acdb71b1b408de3c53fdf892", null ],
    [ "faces", "structsfl_1_1_frame.html#a84582c982787815b9cdd7a86ed3fd25c", null ],
    [ "height", "structsfl_1_1_frame.html#a51283de5627839fa3aeed931e0f5a321", null ],
    [ "id", "structsfl_1_1_frame.html#a49563284302b03b6f13e7d5525c531e7", null ],
    [ "width", "structsfl_1_1_frame.html#ae0ba1301ce4239fc499d94915f8e7b0f", null ]
];