var structsfl_1_1_face =
[
    [ "bbox", "structsfl_1_1_face.html#a70310c5cb6bf1b46e13deae7cc2b7c34", null ],
    [ "id", "structsfl_1_1_face.html#a0a5f4a6bab696fd57857ee3e08483c98", null ],
    [ "landmarks", "structsfl_1_1_face.html#a02d2353b591b486d22045cb8e91310f3", null ]
];