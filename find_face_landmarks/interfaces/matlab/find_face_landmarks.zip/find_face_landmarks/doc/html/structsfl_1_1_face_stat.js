var structsfl_1_1_face_stat =
[
    [ "avg_center_dist", "structsfl_1_1_face_stat.html#a59940a307b75881cdab283ba5ab608ed", null ],
    [ "avg_size", "structsfl_1_1_face_stat.html#a6bc011767a7d35c666f30c678f463f4a", null ],
    [ "central_ratio", "structsfl_1_1_face_stat.html#aa867e5017147347646a3877683163691", null ],
    [ "frame_count", "structsfl_1_1_face_stat.html#af42adb6e56edae7e6e478ce003c35ae2", null ],
    [ "frame_ratio", "structsfl_1_1_face_stat.html#a585289951e43a82e1b853ac266a01f5f", null ],
    [ "id", "structsfl_1_1_face_stat.html#a1962883ceffa98814d532ade63e0f6f4", null ],
    [ "size_ratio", "structsfl_1_1_face_stat.html#aba5b71da5eecde922a0276fba055a6d7", null ]
];