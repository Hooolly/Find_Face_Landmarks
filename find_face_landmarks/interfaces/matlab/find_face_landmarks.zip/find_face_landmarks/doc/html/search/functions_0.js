var searchData=
[
  ['addframe',['addFrame',['../classsfl_1_1_face_tracker.html#abfb36cadc320549ad77ddded36b41f40',1,'sfl::FaceTracker::addFrame()'],['../classsfl_1_1_sequence_face_landmarks.html#aa65faac1c95fca8d022b1536c6f0c1ff',1,'sfl::SequenceFaceLandmarks::addFrame()']]]
];
