var searchData=
[
  ['save',['save',['../classsfl_1_1_sequence_face_landmarks.html#af092dfa695e5545fd81d46e5a979d618',1,'sfl::SequenceFaceLandmarks']]],
  ['setframescale',['setFrameScale',['../classsfl_1_1_sequence_face_landmarks.html#afa114202b21f424fe084b251af3f02c7',1,'sfl::SequenceFaceLandmarks']]],
  ['setinputpath',['setInputPath',['../classsfl_1_1_sequence_face_landmarks.html#a59bf58f022a5f979642e3adb71fa589a',1,'sfl::SequenceFaceLandmarks']]],
  ['setmodel',['setModel',['../classsfl_1_1_sequence_face_landmarks.html#af8301c10711fe624c3b560553293aed8',1,'sfl::SequenceFaceLandmarks']]],
  ['settracking',['setTracking',['../classsfl_1_1_sequence_face_landmarks.html#a4a369b45a675d5941572c9cecc7e06dd',1,'sfl::SequenceFaceLandmarks']]],
  ['size',['size',['../classsfl_1_1_sequence_face_landmarks.html#a853eed169a52b9ae27d20a0fff9a8392',1,'sfl::SequenceFaceLandmarks']]]
];
