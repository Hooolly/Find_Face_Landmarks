var searchData=
[
  ['faces',['faces',['../structsfl_1_1_frame.html#a84582c982787815b9cdd7a86ed3fd25c',1,'sfl::Frame']]],
  ['frame_5fcount',['frame_count',['../structsfl_1_1_face_stat.html#af42adb6e56edae7e6e478ce003c35ae2',1,'sfl::FaceStat']]],
  ['frame_5fratio',['frame_ratio',['../structsfl_1_1_face_stat.html#a585289951e43a82e1b853ac266a01f5f',1,'sfl::FaceStat']]]
];
