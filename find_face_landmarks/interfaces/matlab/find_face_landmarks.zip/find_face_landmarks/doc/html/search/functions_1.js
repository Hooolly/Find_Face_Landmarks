var searchData=
[
  ['clear',['clear',['../classsfl_1_1_face_tracker.html#a7694dff4282c45f6f087db3dbda8a06d',1,'sfl::FaceTracker::clear()'],['../classsfl_1_1_sequence_face_landmarks.html#a3d94182a1c9dbf68a2942b82233c283a',1,'sfl::SequenceFaceLandmarks::clear()']]],
  ['clone',['clone',['../classsfl_1_1_face_tracker.html#a17d82fb1d0c8a8f984124712fd3a33d5',1,'sfl::FaceTracker::clone()'],['../classsfl_1_1_sequence_face_landmarks.html#a7149b88ae349acdf72261f0e6450e7a9',1,'sfl::SequenceFaceLandmarks::clone()']]],
  ['create',['create',['../classsfl_1_1_sequence_face_landmarks.html#ab091a26fd4c2e03b992d2cf098b8547b',1,'sfl::SequenceFaceLandmarks::create(const std::string &amp;landmarks_path, float frame_scale=1.0f, FaceTrackingType tracking=TRACKING_NONE)'],['../classsfl_1_1_sequence_face_landmarks.html#a1632b820aa153b1adc219726e26d3e9c',1,'sfl::SequenceFaceLandmarks::create(float frame_scale=1.0f, FaceTrackingType tracking=TRACKING_NONE)']]],
  ['createfullface',['createFullFace',['../utilities_8h.html#a991bf1e6f978e694f591bdadbfb370f8',1,'sfl']]]
];
