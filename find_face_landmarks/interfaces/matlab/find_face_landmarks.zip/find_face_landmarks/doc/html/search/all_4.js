var searchData=
[
  ['getface',['getFace',['../structsfl_1_1_frame.html#ad8a48313acdb71b1b408de3c53fdf892',1,'sfl::Frame']]],
  ['getfaceapproxeulerangles',['getFaceApproxEulerAngles',['../utilities_8h.html#aaa0b2e09041834e10f2cdb96da7107f8',1,'sfl']]],
  ['getfaceapproxhorangle',['getFaceApproxHorAngle',['../utilities_8h.html#a7399956a6ff8d40e928e06a645a173e7',1,'sfl']]],
  ['getfaceapproxtiltangle',['getFaceApproxTiltAngle',['../utilities_8h.html#a356768d07064476cf1235472510fde99',1,'sfl']]],
  ['getfaceapproxvertangle',['getFaceApproxVertAngle',['../utilities_8h.html#a807caf592c0e604bc58ea4d5005dba8a',1,'sfl']]],
  ['getfacebboxfromlandmarks',['getFaceBBoxFromLandmarks',['../utilities_8h.html#a7628cf77264b184b15b45c509995a21f',1,'sfl']]],
  ['getfacelefteye',['getFaceLeftEye',['../utilities_8h.html#a4e3e4f5634743f538d42883c26ad0aef',1,'sfl']]],
  ['getfacerighteye',['getFaceRightEye',['../utilities_8h.html#acb5124157ab6702b04a9fd0b50a2c095',1,'sfl']]],
  ['getframescale',['getFrameScale',['../classsfl_1_1_sequence_face_landmarks.html#a65155fd9a4340d01ff1ab84e4551b8ba',1,'sfl::SequenceFaceLandmarks']]],
  ['getinputpath',['getInputPath',['../classsfl_1_1_sequence_face_landmarks.html#a382ca75f63a8e7d96da3f13f76475b83',1,'sfl::SequenceFaceLandmarks']]],
  ['getmainfaceid',['getMainFaceID',['../utilities_8h.html#aa730b6f3050bb45fa25bc2246e514f83',1,'sfl::getMainFaceID(const std::list&lt; std::unique_ptr&lt; Frame &gt;&gt; &amp;sequence)'],['../utilities_8h.html#a666768c3073396959ae814f5745e591b',1,'sfl::getMainFaceID(const std::vector&lt; FaceStat &gt; &amp;stats)']]],
  ['getmodel',['getModel',['../classsfl_1_1_sequence_face_landmarks.html#a910bcc3e5239f7e78171e1c37ce5a400',1,'sfl::SequenceFaceLandmarks']]],
  ['getsequence',['getSequence',['../classsfl_1_1_sequence_face_landmarks.html#ad6dc7b2cfa59f5da6f7a8c7495f4b445',1,'sfl::SequenceFaceLandmarks']]],
  ['getsequencemutable',['getSequenceMutable',['../classsfl_1_1_sequence_face_landmarks.html#ac554d3abdbdad29351554e7699ab1c40',1,'sfl::SequenceFaceLandmarks']]],
  ['getsequencestats',['getSequenceStats',['../utilities_8h.html#a0bb848f83b16c6617cb3f083303b9275',1,'sfl']]],
  ['gettracking',['getTracking',['../classsfl_1_1_sequence_face_landmarks.html#a7e61243920e0b017c179bbb26fb104e1',1,'sfl::SequenceFaceLandmarks']]]
];
