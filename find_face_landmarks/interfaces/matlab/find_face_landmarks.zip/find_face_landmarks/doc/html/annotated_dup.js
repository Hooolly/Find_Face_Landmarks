var annotated_dup =
[
    [ "sfl", null, [
      [ "Face", "structsfl_1_1_face.html", "structsfl_1_1_face" ],
      [ "FaceStat", "structsfl_1_1_face_stat.html", "structsfl_1_1_face_stat" ],
      [ "FaceTracker", "classsfl_1_1_face_tracker.html", "classsfl_1_1_face_tracker" ],
      [ "Frame", "structsfl_1_1_frame.html", "structsfl_1_1_frame" ],
      [ "SequenceFaceLandmarks", "classsfl_1_1_sequence_face_landmarks.html", "classsfl_1_1_sequence_face_landmarks" ]
    ] ]
];