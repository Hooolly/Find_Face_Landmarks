var classsfl_1_1_sequence_face_landmarks =
[
    [ "addFrame", "classsfl_1_1_sequence_face_landmarks.html#aa65faac1c95fca8d022b1536c6f0c1ff", null ],
    [ "clear", "classsfl_1_1_sequence_face_landmarks.html#a3d94182a1c9dbf68a2942b82233c283a", null ],
    [ "clone", "classsfl_1_1_sequence_face_landmarks.html#a7149b88ae349acdf72261f0e6450e7a9", null ],
    [ "getFrameScale", "classsfl_1_1_sequence_face_landmarks.html#a65155fd9a4340d01ff1ab84e4551b8ba", null ],
    [ "getInputPath", "classsfl_1_1_sequence_face_landmarks.html#a382ca75f63a8e7d96da3f13f76475b83", null ],
    [ "getModel", "classsfl_1_1_sequence_face_landmarks.html#a910bcc3e5239f7e78171e1c37ce5a400", null ],
    [ "getSequence", "classsfl_1_1_sequence_face_landmarks.html#ad6dc7b2cfa59f5da6f7a8c7495f4b445", null ],
    [ "getSequenceMutable", "classsfl_1_1_sequence_face_landmarks.html#ac554d3abdbdad29351554e7699ab1c40", null ],
    [ "getTracking", "classsfl_1_1_sequence_face_landmarks.html#a7e61243920e0b017c179bbb26fb104e1", null ],
    [ "load", "classsfl_1_1_sequence_face_landmarks.html#a882661b3709c4cd5d890a5ed1f24c955", null ],
    [ "save", "classsfl_1_1_sequence_face_landmarks.html#af092dfa695e5545fd81d46e5a979d618", null ],
    [ "setFrameScale", "classsfl_1_1_sequence_face_landmarks.html#afa114202b21f424fe084b251af3f02c7", null ],
    [ "setInputPath", "classsfl_1_1_sequence_face_landmarks.html#a59bf58f022a5f979642e3adb71fa589a", null ],
    [ "setModel", "classsfl_1_1_sequence_face_landmarks.html#af8301c10711fe624c3b560553293aed8", null ],
    [ "setTracking", "classsfl_1_1_sequence_face_landmarks.html#a4a369b45a675d5941572c9cecc7e06dd", null ],
    [ "size", "classsfl_1_1_sequence_face_landmarks.html#a853eed169a52b9ae27d20a0fff9a8392", null ]
];