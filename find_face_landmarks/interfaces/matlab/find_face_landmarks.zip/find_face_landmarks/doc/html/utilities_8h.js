var utilities_8h =
[
    [ "FaceStat", "structsfl_1_1_face_stat.html", "structsfl_1_1_face_stat" ],
    [ "createFullFace", "utilities_8h.html#a991bf1e6f978e694f591bdadbfb370f8", null ],
    [ "getFaceApproxEulerAngles", "utilities_8h.html#aaa0b2e09041834e10f2cdb96da7107f8", null ],
    [ "getFaceApproxHorAngle", "utilities_8h.html#a7399956a6ff8d40e928e06a645a173e7", null ],
    [ "getFaceApproxTiltAngle", "utilities_8h.html#a356768d07064476cf1235472510fde99", null ],
    [ "getFaceApproxVertAngle", "utilities_8h.html#a807caf592c0e604bc58ea4d5005dba8a", null ],
    [ "getFaceBBoxFromLandmarks", "utilities_8h.html#a7628cf77264b184b15b45c509995a21f", null ],
    [ "getFaceLeftEye", "utilities_8h.html#a4e3e4f5634743f538d42883c26ad0aef", null ],
    [ "getFaceRightEye", "utilities_8h.html#acb5124157ab6702b04a9fd0b50a2c095", null ],
    [ "getMainFaceID", "utilities_8h.html#aa730b6f3050bb45fa25bc2246e514f83", null ],
    [ "getMainFaceID", "utilities_8h.html#a666768c3073396959ae814f5745e591b", null ],
    [ "getSequenceStats", "utilities_8h.html#a0bb848f83b16c6617cb3f083303b9275", null ],
    [ "render", "utilities_8h.html#a06b181344c319e0cada4d6ada4a579ab", null ],
    [ "render", "utilities_8h.html#a97b905a98768d65cdb65d2aa7b33a085", null ],
    [ "render", "utilities_8h.html#a7679b56dc8c857a9de1e401c8389b547", null ],
    [ "render", "utilities_8h.html#adde59815587b12400b5c9c5cda8e1512", null ],
    [ "renderFaceID", "utilities_8h.html#a1ebd8c9cb6b798af0f587ae71bfc6865", null ]
];